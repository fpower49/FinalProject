"""
Class: CS230--Section 1
Name: Finn Power
Description: Final Project, Volcano Dataset
I pledge that I have completed the programming assignment independently.
I have not copied the code from a student or any source.
I have not given my code to any student.
"""
import pandas as pd
import streamlit as st
import numpy as np
from streamlit_option_menu import option_menu
import matplotlib.pyplot as plt
import random
import pydeck as pdk


def display_description():
    st.subheader('Background')
    description = """Volcanoes are a mountain or hill, typically conical, having a crater or vent through
                    which lava, rock fragments, hot vapor, and gas are being or have been erupted from the earth's 
                    crust"""
    return description


def display_maps_one(df):
    df2 = df[['Latitude', 'Longitude']].copy()
    df2 = df2.rename(columns={'Latitude': 'lat', 'Longitude': 'lon'})
    return df2

def display_maps_two(df, country):
    df2 = df[['Country', 'Latitude', 'Longitude']].copy()
    df2 = df2.rename(columns={'Latitude': 'lat', 'Longitude': 'lon'})
    df2.set_index('Country', inplace=True)
    df2 = df2.loc[country]
    st.subheader('Dataframe of Selected Country: ')
    st.write(df2)
    st.subheader("Map of Selected Country's Volcanic Eruptions")
    return df2


def chart_one(df):
    counts = df['Region'].value_counts()
    fig, ax = plt.subplots()
    ax.bar(range(len(counts[0:])), counts[0:], color='g')
    ax.set_xlabel('Region of Eruption')
    ax.set_title('Number of Eruptions in Each Region')
    ax.set_xticks((range(len(counts[0:]))))
    ax.set_xticklabels(counts.index[0:], rotation='vertical')

    st.pyplot(fig)


# def chart_two(df):


def add(dict):
    number = random.randint(390848, 390999)
    st.title('Add New/Missing Eruption Information')
    st.subheader('For complete entry, fill out all boxes')
    name = st.text_input('Enter Volcano Name: ')
    dict['Volcano Name'][number] = name
    country = st.text_input('Enter Country Containing Volcano: ')
    dict['Country'][number] = country
    type = st.text_input('Enter Primary Volcano Type: ')
    dict['Primary Volcano Type'][number] = type
    evidence = st.text_input('Enter Activity Evidence: ')
    dict['Activity Evidence'][number] = evidence
    eruption_time = st.text_input('Enter Last Known Eruption: ')
    dict['Last Known Eruption'][number] = eruption_time
    region = st.text_input('Enter Region of Eruption: ')
    dict['Region'][number] = region
    subregion = st.text_input('Enter Subregion of Eruption: ')
    dict['Subregion'][number] = subregion
    lat = st.number_input('Enter Latitude of Volcano: ')
    dict['Latitude'][number] = lat
    lon = st.number_input('Enter Longitude of Volcano: ')
    dict['Longitude'][number] = lon
    elevation = st.number_input('Enter Elevation of Volcano: ')
    dict['Elevation (m)'][number] = elevation
    rock_type = st.text_input('Enter Dominant Rock Type: ')
    dict['Dominant Rock Type'][number] = rock_type
    tectonic_setting = st.text_input('Enter Tectonic Setting: ')
    dict['Tectonic Setting'][number] = tectonic_setting
    return dict


def chart_three(df):
    elevation_df = df['Elevation (m)'].values
    point = elevation_df[-1]
    data = [elevation_df, point]
    st.caption('Dataframes from Volcano Elevations')
    st.write(elevation_df)
    fig, ax = plt.subplots()
    ax.boxplot(data, vert=False, showmeans=True)
    ax.set_title('Box and Whisker Plot of Elevation of Volcanoes')
    ax.set_xlabel('Distribution of Elevation')
    ax.set_yticklabels(['Plot of All Data', 'Newly Added Elevation Point'])
    st.pyplot(fig)


def main():
    df = pd.read_csv("Volcano.csv", header=1, index_col=0)
    dict = df.to_dict()
    selected = option_menu(
        menu_title='Volcano Main Menu',
        options=['Home Page', 'Maps', 'Charts', 'Page Contributions'],
        icons=['globe', 'map', 'chart'],
        menu_icon="cast",
        default_index=0,
        orientation='horizontal',
    )
    if selected == 'Home Page':
        st.title('Welcome to My Website on Volcanoes')
        st.image('volcanoes.jpg')
        description = display_description()
        st.write(description)
        display = display_maps_one(df)
        st.subheader("Map of Selected Country's Volcanic Eruptions")
        st.map(display)
    if selected == 'Charts':
        st.subheader('Chart 1: ')
        chart_one(df)
        st.subheader('Chart 2: ')
        # chart_two(df)
    if selected == 'Maps':
        country = st.text_input('Enter a country you wish to display data for: ')
        if country in df['Country'].values:
            display = display_maps_two(df, country)
            st.write(display)

            #chart_data = pd.DataFrame(
             #   np.random.randn(1000, 2) / [50, 50] + [37.76, -122.4],
              #  columns=['lat', 'lon'])

            st.pydeck_chart(pdk.Deck(
                map_style=None,
                initial_view_state=pdk.ViewState(
                    latitude=37.76,
                    longitude=-122.4,
                    zoom=11,
                    pitch=50,
                ),
                layers=[
                    pdk.Layer(
                        'HexagonLayer',
                        data=display,
                        get_position='[lon, lat]',
                        radius=200,
                        elevation_scale=4,
                        elevation_range=[0, 1000],
                        pickable=True,
                        extruded=True,
                    ),
                    pdk.Layer(
                        'ScatterplotLayer',
                        data=display,
                        get_position='[lon, lat]',
                        get_color='[200, 30, 0, 160]',
                        get_radius=200,
                    ),
                ],
            ))
    if selected == 'Page Contributions':
        new_dict = add(dict)
        new_df = pd.DataFrame(new_dict)
        st.caption('New Eruption Entered by User')
        st.write(new_df.tail(1))
        chart_three(new_df)


main()
